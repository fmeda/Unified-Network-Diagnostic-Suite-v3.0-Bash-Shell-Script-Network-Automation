#!/usr/bin/env bash
# Network Diagnostic Suite v2.0 - interactive TUI and ephemeral credentials
set -uo pipefail
umask 077
VERSION="3.0"
BASE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-$BASE_DIR/reports}"
mkdir -p "$OUTPUT_DIR"
REPORT="$OUTPUT_DIR/report_$(date -u +%Y%m%dT%H%M%SZ).csv"
printf 'timestamp,category,target,status,details\n' > "$REPORT"
DNS_SERVERS=(1.1.1.1 8.8.8.8)
DOMAINS=(example.com)
DNS_TYPES=(A AAAA MX NS TXT SOA)
TARGETS=(127.0.0.1)
PORTS=(22 53 80 443)
TIMEOUT=3
AUTH_USER='' AUTH_SECRET='' AUTH_URL=''
AUTH_SET=0
SWITCH_HOST='' SWITCH_USER='' SWITCH_VENDOR='cisco-ios' SWITCH_PORT='22' SWITCH_INTERFACE='GigabitEthernet1/0/1'
RED=$'\033[31m' GREEN=$'\033[32m' BLUE=$'\033[36m' RESET=$'\033[0m'
cleanup(){
  AUTH_USER='' AUTH_SECRET='' AUTH_URL='' AUTH_SET=0
  unset AUTH_USER AUTH_SECRET AUTH_URL AUTH_SET
}
trap cleanup EXIT
trap 'cleanup; exit 130' INT
trap 'cleanup; exit 143' TERM
log(){
  local detail="${4//$'\n'/ }"
  detail="${detail//$'\r'/ }"
  detail="${detail//\"/\"\"}"
  printf '"%s","%s","%s","%s","%s"\n' "$(date -u +%FT%TZ)" "$1" "$2" "$3" "$detail" >> "$REPORT"
  printf '%-14s %-32s %s\n' "$1" "$2" "$3"
}
header(){
  clear 2>/dev/null || true
  printf '%s\n' "${BLUE}╔════════════════════════════════════════════════════════════╗${RESET}" \
    "${BLUE}║      UNIFIED NETWORK DIAGNOSTIC SUITE — SHELL v${VERSION}      ║${RESET}" \
    "${BLUE}╚════════════════════════════════════════════════════════════╝${RESET}"
  printf 'Targets: %s | DNS: %s | Credential: %s\n' "${TARGETS[*]}" "${DNS_SERVERS[*]}" "$([[ "$AUTH_SET" == 1 ]] && echo 'in memory' || echo 'none')"
  echo "Report: $REPORT"
  echo
}
pause(){ read -r -p 'Press ENTER to continue...' _ || true; }
prompt_list(){
  local title="$1" var="$2" raw
  read -r -p "$title (space-separated): " raw || return
  [[ -z "$raw" ]] && return
  local -a words=()
  read -r -a words <<< "$raw"
  ((${#words[@]})) && declare -p words >/dev/null && case "$var" in
    dns) DNS_SERVERS=("${words[@]}");;
    domains) DOMAINS=("${words[@]}");;
    targets) TARGETS=("${words[@]}");;
    ports) PORTS=("${words[@]}");;
  esac
}
valid_host(){
  [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9._:-]{0,252}$ && "$1" != -* ]]
}
valid_port(){ [[ "$1" =~ ^[0-9]{1,5}$ ]] && ((10#$1 >= 1 && 10#$1 <= 65535)); }
valid_dns_type(){ [[ "$1" =~ ^(A|AAAA|MX|NS|TXT|SOA|CNAME|PTR|CAA)$ ]]; }
valid_timeout(){ [[ "$1" =~ ^[1-9][0-9]?$ ]]; }
timeout_run(){ timeout "${TIMEOUT}s" "$@"; }
dns_test(){
  command -v dig >/dev/null || { log DNS "$1" unavailable "dig missing"; return; }
  local server="$1" domain="$2" typ="$3" proto="$4" out rc
  valid_host "$server" && valid_host "$domain" && valid_dns_type "$typ" || { log DNS "$server/$domain" invalid "Invalid DNS parameter"; return; }
  local -a opt=()
  [[ "$proto" == tcp ]] && opt=(+tcp)
  out=$(timeout_run dig @"$server" "$domain" "$typ" "${opt[@]}" +time="$TIMEOUT" +tries=1 +noall +comments +answer 2>&1); rc=$?
  if ((rc!=0)); then log DNS "$server/$domain/$typ/$proto" error "exit=$rc $(printf '%s' "$out" | tail -c 200)"
  elif grep -q 'status: NOERROR' <<< "$out"; then log DNS "$server/$domain/$typ/$proto" ok "$(printf '%s' "$out" | tail -c 350)"
  else log DNS "$server/$domain/$typ/$proto" warning "$(printf '%s' "$out" | tail -c 350)"; fi
}
dns_all(){
  local s d t proto
  for s in "${DNS_SERVERS[@]}"; do
    for d in "${DOMAINS[@]}"; do
      for t in "${DNS_TYPES[@]}"; do
        for proto in udp tcp; do dns_test "$s" "$d" "$t" "$proto"; done
      done
    done
  done
}
tcp_all(){
  local h p rc
  command -v nc >/dev/null || { log TCP all unavailable "nc missing"; return; }
  for h in "${TARGETS[@]}"; do
    valid_host "$h" || { log TCP "$h" invalid "Invalid target"; continue; }
    for p in "${PORTS[@]}"; do
      valid_port "$p" || { log TCP "$h:$p" invalid "Invalid port"; continue; }
      timeout_run nc -z -w "$TIMEOUT" "$h" "$p" >/dev/null 2>&1; rc=$?
      if ((rc==0)); then log TCP "$h:$p" ok "connected"; else log TCP "$h:$p" error "exit=$rc"; fi
    done
  done
}
ping_all(){
  local h out rc
  for h in "${TARGETS[@]}"; do
    valid_host "$h" || continue
    out=$(timeout 12 ping -c 3 -W "$TIMEOUT" "$h" 2>&1); rc=$?
    log PING "$h" "$([[ $rc == 0 ]] && echo ok || echo error)" "$(printf '%s' "$out" | tail -n 3)"
  done
}
trace_all(){
  local h out rc
  command -v traceroute >/dev/null || { log TRACE all unavailable "traceroute missing"; return; }
  for h in "${TARGETS[@]}"; do
    valid_host "$h" || continue
    out=$(timeout 25 traceroute -n -m 12 -w 1 "$h" 2>&1); rc=$?
    log TRACE "$h" "$([[ $rc == 0 ]] && echo ok || echo warning)" "$(printf '%s' "$out" | tail -n 5)"
  done
}
interface_all(){
  local d name state speed mtu key val
  for d in /sys/class/net/*; do
    [[ -d "$d" ]] || continue
    name="${d##*/}"
    state=$(cat "$d/operstate" 2>/dev/null || echo unknown)
    speed=$(cat "$d/speed" 2>/dev/null || echo unknown)
    mtu=$(cat "$d/mtu" 2>/dev/null || echo unknown)
    log INTERFACE "$name" "$state" "speed_mbps=$speed mtu=$mtu"
    for key in rx_errors tx_errors rx_dropped tx_dropped rx_crc_errors; do
      [[ -r "$d/statistics/$key" ]] || continue
      val=$(cat "$d/statistics/$key")
      log COUNTER "$name/$key" ok "$val"
    done
  done
}
mtu_all(){
  local h out rc size
  read -r -p 'ICMP payload bytes [1400]: ' size || return
  size="${size:-1400}"
  [[ "$size" =~ ^[0-9]{1,5}$ ]] && ((size >= 1 && size <= 65000)) || { echo "Invalid size"; return; }
  for h in "${TARGETS[@]}"; do
    valid_host "$h" || continue
    out=$(timeout 10 ping -c 1 -M do -s "$size" "$h" 2>&1); rc=$?
    log MTU "$h" "$([[ $rc == 0 ]] && echo ok || echo warning)" "payload=$size $(printf '%s' "$out" | tail -n 2)"
  done
}
set_credentials(){
  echo "HTTPS Basic credentials: stored only in shell variables during this session."
  echo "Warning: memory cannot be guaranteed wiped; no credentials are written to reports."
  local user secret confirm
  read -r -p "Username: " user || return
  [[ -n "$user" ]] || { echo "Username required"; return; }
  read -r -s -p "Password/token (hidden): " secret || return
  echo
  [[ -n "$secret" ]] || { echo "Password/token required"; return; }
  AUTH_USER="$user"; AUTH_SECRET="$secret"; AUTH_SET=1
  user='' secret=''
  unset user secret
  echo "Credentials available for authenticated HTTPS test."
}
delete_credentials(){
  cleanup
  AUTH_USER='' AUTH_SECRET='' AUTH_URL='' AUTH_SET=0
  echo "Session credential variables unset. No persistent credential store was used."
}
auth_http(){
  [[ "$AUTH_SET" == 1 ]] || { echo "Set credentials first (menu 8)."; return; }
  command -v curl >/dev/null || { echo "curl required"; return; }
  local url host response rc
  read -r -p "HTTPS URL: " url || return
  [[ "$url" =~ ^https://[A-Za-z0-9._:-]+(/[^[:space:]]*)?$ ]] || { echo "HTTPS URL required"; return; }
  host="${url#https://}";host="${host%%/*}"
  echo "Connecting to $host using TLS verification and Basic authentication."
  # Credentials supplied via curl config on stdin; not placed in process arguments.
  # curl's output is limited to status/time and never logs response body.
  response=$(
    printf 'user = "%s:%s"\n' "${AUTH_USER//\"/\\\"}" "${AUTH_SECRET//\"/\\\"}" |
    timeout_run curl --config - --silent --show-error --output /dev/null \
      --write-out 'http=%{http_code} total_s=%{time_total}' --head "$url" 2>&1
  ); rc=$?
  if ((rc==0)); then log HTTPS "$host" ok "$response"; else
    # curl error output can contain remote-controlled strings; do not log it.
    log HTTPS "$host" error "curl_exit=$rc"
  fi
  echo "Credential variables retained until deletion, replacement, or exit."
}

# Read-only SSH switch-port diagnostics: key/agent authentication, strict host-key checks.
# Supports Cisco IOS/IOS-XE, Cisco NX-OS, Aruba CX, Dell OS10, Huawei VRP.
switch_validate_interface(){
  local v="$1" iface="$2"
  [[ ${#iface} -le 80 && "$iface" =~ ^[A-Za-z][A-Za-z0-9/._:-]*$ ]] || return 1
  case "$v" in
    cisco-ios|cisco-nxos|aruba-cx|dell-os10|huawei-vrp) return 0;;
    *) return 1;;
  esac
}
switch_commands(){
  local vendor="$1" iface="$2"
  case "$vendor" in
    cisco-ios)
      printf '%s\n' "terminal length 0" "show interfaces $iface" \
        "show interfaces $iface status" "show interfaces $iface switchport" \
        "show interfaces $iface counters errors" "show logging | include $iface"
      ;;
    cisco-nxos)
      printf '%s\n' "terminal length 0" "show interface $iface" \
        "show interface $iface switchport" "show interface $iface counters errors" \
        "show logging last 30"
      ;;
    aruba-cx)
      printf '%s\n' "no page" "show interface $iface" \
        "show interface $iface statistics" "show vlan" \
        "show logging -r"
      ;;
    dell-os10)
      printf '%s\n' "terminal length 0" "show interface $iface" \
        "show interface $iface counters" "show interface $iface switchport" \
        "show logging"
      ;;
    huawei-vrp)
      printf '%s\n' "screen-length 0 temporary" "display interface $iface" \
        "display current-configuration interface $iface" \
        "display logbuffer"
      ;;
  esac
}
switch_configure(){
  local h u v p i
  read -r -p "Switch hostname/IP: " h || return
  read -r -p "SSH username: " u || return
  read -r -p "Vendor [cisco-ios|cisco-nxos|aruba-cx|dell-os10|huawei-vrp]: " v || return
  read -r -p "Interface [e.g. GigabitEthernet1/0/1, Ethernet1/1, 1/1/1]: " i || return
  read -r -p "SSH port [22]: " p || return
  p="${p:-22}"
  if ! valid_host "$h" || [[ ! "$u" =~ ^[A-Za-z_][A-Za-z0-9_.-]{0,63}$ ]] ||
     ! valid_port "$p" || ! switch_validate_interface "$v" "$i"; then
    echo "Invalid switch configuration; no SSH commands executed."
    return 1
  fi
  SWITCH_HOST="$h"; SWITCH_USER="$u"; SWITCH_VENDOR="$v"; SWITCH_INTERFACE="$i"; SWITCH_PORT="$p"
  echo "Switch configured. SSH agent or existing SSH key required."
}
switch_diagnostics(){
  [[ -n "$SWITCH_HOST" && -n "$SWITCH_USER" ]] || { echo "Configure a switch first (menu 13)."; return 1; }
  command -v ssh >/dev/null || { log SWITCH "$SWITCH_HOST" unavailable "OpenSSH client required"; return 1; }
  if ! valid_host "$SWITCH_HOST" ||
     [[ ! "$SWITCH_USER" =~ ^[A-Za-z_][A-Za-z0-9_.-]{0,63}$ ]] ||
     ! valid_port "$SWITCH_PORT" ||
     ! switch_validate_interface "$SWITCH_VENDOR" "$SWITCH_INTERFACE"; then
    log SWITCH "$SWITCH_HOST" invalid "Invalid parameters"
    return 1
  fi
  local cmd output rc
  local outfile="$OUTPUT_DIR/switch_$(date -u +%Y%m%dT%H%M%SZ)_$$.txt"
  ( umask 077; : > "$outfile" )
  printf 'Device: %s\nVendor: %s\nInterface: %s\nTimestamp: %s\n\n' \
    "$SWITCH_HOST" "$SWITCH_VENDOR" "$SWITCH_INTERFACE" "$(date -u +%FT%TZ)" >> "$outfile"
  # A fixed allowlist of read-only show/display commands. Never run configure commands.
  while IFS= read -r cmd; do
    [[ -n "$cmd" ]] || continue
    printf '\n### %s\n' "$cmd" >> "$outfile"
    # stdin is /dev/null: no remote command injection via stdin.
    # BatchMode disables password prompts; host key checking remains strict.
    output=$(timeout 18 ssh -T -n -p "$SWITCH_PORT" \
      -o BatchMode=yes -o StrictHostKeyChecking=yes \
      -o ConnectTimeout=5 -o ConnectionAttempts=1 \
      -- "${SWITCH_USER}@${SWITCH_HOST}" "$cmd" 2>&1); rc=$?
    # Avoid logging command output in CSV; sensitive device details stay in chmod 600 text file.
    printf '%s\n' "$output" >> "$outfile"
    log SWITCH "$SWITCH_HOST/$SWITCH_INTERFACE" "$([[ $rc == 0 ]] && echo ok || echo error)" \
      "vendor=$SWITCH_VENDOR command=$cmd exit=$rc"
    # Authentication/transport failure: do not retry every command.
    if (( rc == 255 || rc == 124 )); then
      echo "SSH transport failure or timeout; stopping diagnostics."
      break
    fi
  done < <(switch_commands "$SWITCH_VENDOR" "$SWITCH_INTERFACE")
  chmod 600 "$outfile"
  echo "Switch evidence saved to: $outfile"
}

configure(){
  while true; do
    header
    echo '1) DNS servers  2) Domains  3) Targets  4) TCP ports  5) Timeout  0) Back'
    read -r -p 'Option: ' ch || return
    case "$ch" in
      1) prompt_list 'DNS servers' dns;;
      2) prompt_list 'Domains' domains;;
      3) prompt_list 'Targets' targets;;
      4) prompt_list 'Ports' ports;;
      5) read -r -p 'Timeout seconds (1-99): ' v; if valid_timeout "$v"; then TIMEOUT="$v"; else echo invalid; sleep 1; fi;;
      0) return;;
    esac
  done
}
run_all(){ dns_all; tcp_all; ping_all; trace_all; interface_all; }
menu(){
  while true; do
    header
    cat <<'MENU'
 1) Configure targets, DNS and ports
 2) DNS diagnostic (UDP/TCP)
 3) TCP connectivity
 4) ICMP ping
 5) Traceroute
 6) Local Ethernet interfaces and error counters
 7) MTU test (Linux)
 8) Enter temporary HTTPS credentials
 9) Authenticated HTTPS HEAD test
10) Delete session credentials
11) Run main diagnostics
12) Show report location
13) Configure switch (SSH key/agent)
14) Diagnose switch interface (read-only)
 0) Exit (automatic credential deletion)
MENU
    read -r -p 'Choose: ' choice || break
    case "$choice" in
      1) configure;;
      2) dns_all; pause;;
      3) tcp_all; pause;;
      4) ping_all; pause;;
      5) trace_all; pause;;
      6) interface_all; pause;;
      7) mtu_all; pause;;
      8) set_credentials; pause;;
      9) auth_http; pause;;
      10) delete_credentials; pause;;
      11) run_all; pause;;
      12) echo "$REPORT"; pause;;
      13) switch_configure; pause;;
      14) switch_diagnostics; pause;;
      0) break;;
      *) echo 'Invalid choice'; sleep 1;;
    esac
  done
}
if [[ "${1:-}" == "--self-test" ]]; then
  valid_host example.com && valid_port 443 && valid_dns_type AAAA && valid_timeout 3 &&
  switch_validate_interface cisco-ios GigabitEthernet1/0/1 &&
  switch_validate_interface cisco-nxos Ethernet1/1 &&
  ! switch_validate_interface cisco-ios "Gi1/0/1;reload" &&
  ! switch_validate_interface invalid-vendor Ethernet1/1 &&
  ! valid_port 99999 && ! valid_host '--bad' && echo 'SELFTEST PASS'
  exit
fi
menu
