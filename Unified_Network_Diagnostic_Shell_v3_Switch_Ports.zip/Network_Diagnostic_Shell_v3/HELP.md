# Unified Network Diagnostic Suite v2 — Bash TUI

## Requirements
Linux, Bash 4+, coreutils (`timeout`), `dig`, `nc`, `ping`, `traceroute`, `curl`.
Ubuntu: `sudo apt install dnsutils netcat-openbsd iputils-ping traceroute curl coreutils`

## Run
`chmod +x network_suite.sh && ./network_suite.sh`

Use menu **1** to configure DNS, domains, hosts, ports, and timeout.
Use menu **8** to enter HTTPS Basic username and password/token without echo.
Use menu **9** for authenticated HTTPS HEAD request (TLS certificate validation remains enabled).
Use menu **10** to delete session variables; exiting also triggers cleanup.

## Credential lifecycle
- Interactive secret entry with `read -s`; no secrets in config files, logs, report CSV or shell history.
- Credentials stay in Bash process memory until manually deleted, replaced, or exit.
- Curl receives Basic credentials via stdin config, not via command-line arguments.
- Bash `unset` is *best-effort variable deletion*, **not guaranteed secure memory erasure**.
- OS process inspection, swap, shell debugging, core dumps, compromised hosts, or privileged observers can still expose secrets. Never run with `bash -x`.
- HTTPS only, normal certificate verification, no `-k` insecure flag.
- No automatic access to SSH, SNMP, switches, or firewalls in this edition. For SSH use agent/keys and interactive authentication; avoid passwords on command lines.

## Diagnostics
DNS over UDP/TCP, TCP connect, ping, traceroute, Linux local NIC counters, MTU probe, HTTPS HEAD with optional authentication.
All checks are read-only and must be run only on authorized targets.
Report: `reports/report_YYYYMMDDTHHMMSSZ.csv`.

## Scope/limitations
This is not all 30 planned features. Advanced PCAP analysis, SNMP/SSH collection, DNSSEC validation, automatic RCA, Zabbix/Wazuh/Grafana integrations, and a graphical dashboard are not implemented.
HTTP authentication is only Basic, and remote endpoints may not support HEAD.
CSV details are escaped for quotes/newlines; do not open reports as trusted spreadsheet formulas if target strings are untrusted.

## v3: Switch physical port diagnosis via SSH

Menu **13**: configure device hostname/IP, SSH username, vendor, physical port.
Menu **14**: run read-only commands and save detailed evidence.

Supported:
- Cisco IOS/IOS-XE: `show interfaces`, `show interfaces status`, `switchport`, counters errors, interface-specific logs.
- Cisco NX-OS: interface, switchport, error counters, recent logs.
- Aruba CX: interface, statistics, VLANs, logs.
- Dell OS10: interface, counters, switchport, logs.
- Huawei VRP: interface, current interface configuration, logs.

SSH uses keys or `ssh-agent` only (BatchMode), strict host-key validation,
no password on command line, no password stored on disk.
Prepare device access with `ssh-keygen`, authorized keys and verified `known_hosts`.
Device CLI syntax varies by firmware; unsupported commands are recorded as errors.
No interface shut/no shut, configuration mode, port-security changes, or other
configuration changes are performed. `terminal length 0`, `no page`, and
`screen-length 0 temporary` are session-scoped display commands.

Evidence files are saved in reports/ with mode 600. These can contain device
configuration details and should be handled as sensitive.

The existing temporary credential feature is **only for HTTPS Basic**; switch SSH
access intentionally uses keys/agent instead of password variables.
Do not use this tool against switches without authorization.
